package com.example.miniproject;

public class DataList {
    String allcustomers;

    public DataList(String allcustomers) {
        this.allcustomers = allcustomers;
    }

    public DataList() {
    }

    public String getAllcustomers() {
        return allcustomers;
    }

    public void setAllcustomers(String allcustomers) {
        this.allcustomers = allcustomers;
    }
}
